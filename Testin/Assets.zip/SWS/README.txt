************************************
IMPORTANT
************************************

************************************ 
INSTALLATION
************************************

Please read the documentation pdf "SimpleWaypointSystem"
for a quick start guide and further information.

PlayMaker users: Please have a look at the PlayMaker
addon package and additional docs in the "Plugins" folder.

************************************ 
SUPPORT
************************************ 

For support queries, visit our support forum or drop us a line.
To support us, please consider writing a review on the Asset
Store. The corresponding links are located in the top menu
under Window > Simple Waypoint System > About. Thank you!

************************************ 